# GeideaPay - Prestashop Geidea Payment Gateway Module

## Installation

1 - Clone the Prestashop plugin folder and rename it to 'geideapay'

2 - Zip the 'geideapy' folder

3 - Upload it as a module to your Prestashop store
