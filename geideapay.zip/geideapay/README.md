# GeideaPay - Prestashop Geidea payment gateway module

## Installation

1 - download the folder and rename it to 'geideapay'

2 - Zip the folder

3 - Upload it as a module
